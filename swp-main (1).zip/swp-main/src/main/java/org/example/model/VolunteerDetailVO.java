package org.example.model;

public interface VolunteerDetailVO {
     String getEmail();
     String getFullName();
     String getPhone();
     String getAddress();
     String getStatus();
     String getDob();
     String getCccd();
     String getExperience();
     String getCurrentJob();
     String getReason();
     String getGender();
}
