package org.example.data.response;

public class DropdownPetTypeResponse {
}
